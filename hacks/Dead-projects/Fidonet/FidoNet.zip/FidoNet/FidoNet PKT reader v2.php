#!/usr/bin/php
<?php

require "common.php.inc";
require "fidonet.php.inc";

foreach (array(
	'VISIBLE_TEARLINES' => false,
	'VISIBLE_ORIGIN' => false,
	'VISIBLE_SEENBY' => false,
) as $k => $v) define($k, $v);

$attributes = array(
	'PRIVATE',
	'CRASH',
	'BEENREAD',
	'SENT',
	'ATTACH',
	'FORWARD',
	'UNKNOWN_DEST',
	'KILLSEN',
	'IS_LOCAL',
	'NOTHINGYET',
	'NOTHINGYET2',
	'FREQ',
	'RECEIPT_REQD',
	'IS_RECEIPT',
	'AUDIT_REQD',
	'UPDATE_REQD',
); foreach ($attributes as $i => $name) define("MSGATTR_{$name}", 1 << $i);

# stats
$messageCount = 0;
$pktCount = 0;

class Packet {
	# of packet itself
	public $origin;
	public $destination;
	
	# of packet creation
	public $creationDate;
	public $version;
	public $messages = array();
}

class Message {
	# actually I could just use class Message { }
	
	# origin/dest in header (may not match the ones in body)
	public $hOrigin;
	public $hDestination;
	
	# huh?
	public $attribute;
	public $cost;
	
	# message metadata
	public $rawSender;
	public $rawRecipient;
	public $rawSubject;
	public $rawText; # unparsed, un-iconv'd
	
	public $sender;
	public $recipient;
	public $subject;
	public $text;
	public $kludges = array();
	
	public $tearline;
	public $originLine;
	public $trueOriginLine;
	public $seenBy = array();
	
	public $originalCharset;
}

class Address {
	public $zone;
	public $region;
	public $node;
	public $point;
	public $domain;
	
	public function __construct($z = null, $r = null, $n = null, $p = null, $d = null) {
		if (is_string($z) and $r === null and $n === null and $p === null and $d === null) {
			$this->zone = intval(strtok($z, ":"));
			$this->region = intval(strtok("/"));
			$this->node = intval(strtok("."));
			$this->point = intval(strtok("@"));
			$this->domain = strtok("");
			
			if (empty($this->zone)) $this->zone = null;
			if (empty($this->region)) $this->region = null;
			if (empty($this->node)) $this->node = null;
			if (empty($this->point)) $this->point = null;
			if (empty($this->domain)) $this->domain = null;
		}
		else {
			$this->zone = (int)$z;
			$this->region = (int)$r;
			$this->node = (int)$n;
			$this->point = $p;
			$this->domain = $d;
		}
	}
	public function __toString() {
		# only add an element if a higher element exists
		$addr = "{$this->zone}";
		if ($this->region !== null) {
			$addr .= ":{$this->region}";
			if ($this->node !== null) {
				$addr .= "/{$this->node}";
				if ($this->point !== null) {
					$addr .= ".{$this->point}";
					if ($this->domain !== null) {
						$addr .= "@{$this->domain}";
					}
				}
			}
		}
		return $addr;
	}
}

class Attribute {
}

function kGetCharset($charset, $level = 0) {
	# official definitions from FSP-1013
	$charset = strtoupper($charset);
	switch ($level) {
	case 1: # level 1 (7 bit)
		switch ($charset) {
		case "ASCII": return 'iso-ir-6';
		
		case "DUTCH": return 'iso-ir-21';
		
		case "ISO-10": # deprecated, back-compat
		case "SWEDISH":
		case "FINNISH": return 'iso-ir-8-1';
		
		case "FRENCH": return 'iso-ir-69';
		case "CANADIAN": return 'iso-ir-122';
		case "GERMAN": return 'iso-ir-21';
		case "ITALIAN": return 'iso-ir-15';
		case "NORWEIG": return 'iso-ir-60';
		
		# TODO: iso-ir-84 for PORTU/SPANISH?
		case "PORTU": return 'iso-ir-16';
		case "SPANISH": return 'iso-ir-17';

		# TODO: find SWISS map
		case "SWISS": return null;
		
		case "UK": return 'iso-ir-4';
		
		default: return false;
		} break;
		
	case 2: # level 2 (8 bit, ASCII based)
		switch ($charset) {
		case "CP437": return "cp437";
		case "CP850": return "cp850";
		case "CP865": return "cp865";
		
		case "+7_FIDO": # deprecated
		case "CP866": return "cp866";
		
		case "LATIN-1": return "iso8859-1";
		case "LATIN-2": return "iso8859-2";
		case "LATIN-5": return "iso8859-9";
		case "MAC": return "mac";
		
		case "IBMPC": return false;
		default: return false;
		} break;
	
	case 3: # no known implementations
	case 4: # no known implementations
	default: return false;
	}
	
	return false;
}

# 2:5004/75.354
function readpkt($fh) {
	$P = new Packet();
	
	# read header
	$h = fread($fh, 58);
	$pktversion = unpack("x16/vsubversion/vversion", $h);
	
	if ($pktversion['subversion'] == 2) {
		# PKT 2.2 (FSC-0045)
		# x8/x2/x2 stand for reserved, subversion (above), and version (above)
		$h = unpack("vorigNode/vdestNode/vorigPoint/vdestPoint/x8/x2/x2/vorigNet/vdestNet/cprodcode/cserialno/a8password/vorigZone/vdestZone/a8origdomain/a8destdomain/Vproddata", $h);
	}
	elseif (false) { # TODO: detect 2 / 2+
		# PKT 2+ (FSC-0039)
		# v3date/v3time -> vcYear/vcMonth/vcDay/vcHour/vcMin/vcSec
		$h = unpack("vorigNode/vdestNode/vcYear/vcMonth/vcDay/vcHour/vcMin/vcSec/vbaud/x2/vorigNet/vdestNet/cprodcode/crevisionMajor/a8password/vorigZoneQ/vdestZoneQ/x4/cprodcodeHi/crevisionMinor/vcapabilities/vorigZone/vdestZone/vorigpoint/vdestpoint/Vproddata", $h);
		
		$h['prodcode'] = ($h['prodcodeHi'] << 8) + $h['prodcode'];
		unset ($h['prodcodeHi']);
	}
	else {
		# PKT 2 (FSC-0001)
		$h = unpack("vorigNode/vdestNode/v3date/v3time/vbaud/x2/vorigNet/vdestNet/cprodcode/cserialno/a8password/vorigZone/vdestZone/x20", $h);
	}
	
	# packet data
	$P->version = $h['pktversion'];
	
	if (!isset($h['origpoint'])) $h['origpoint'] = null;
	if (!isset($h['origdomain'])) $h['origdomain'] = null;
	$P->origin = new Address($h['origzone'], $h['orignet'], $h['orignode'], $h['origpoint'], $h['origdomain']);
	
	if (!isset($h['destpoint'])) $h['destpoint'] = null;
	if (!isset($h['destdomain'])) $h['destdomain'] = null;
	$P->destination = new Address($h['destzone'], $h['destnet'], $h['destnode'], $h['destpoint'], $h['destdomain']);
	
	if (isset($h['cYear']))
		$P->creationDate = mktime($h['cHour'], $h['cMin'], $h['cSec'], $h['cMonth'], $h['cDay'], $h['cYear']);
		# $P->creationDate = mktime($h['time1'], $h['time2'], $h['time3'], $h['date2'], $h['date3'], $h['date1']);
		
	
	var_dump($h, $P); die;
	
	unset($h);
	
	
	# read packed messages
	while (true) {
		$magic = fread($fh, 2);
		$magic = unpack("v", $magic);
		switch ($magic[1]) {
		case 0x0000:
			break 2;
		case 0x0002:
			$P->messages[] = readMessage($fh, $P);
			break 2;
		default:
			fwrite(STDERR, "Unknown packed message type 0x".bin2hex($magic[1])."\n");
			return false;
		}
	} # continue to next packed message
	
	$_GLOBALS["pktCount"]++;
	return $P;
}

function readMessage($fh, $P) {
	$M = new Message();
	
	# 12 bytes: source, destination, attribute, cost
	$header = unpack("v*", fread($fh, 12));
	$M->hOrigin = new Address($P->origin->zone, $header[3], $header[1]);
	$M->hDestination = new Address($P->destination->zone, $header[4], $header[2]);
	# TODO: attribute ($header[5])
	$M->cost = $header[6];
	unset($header);
	
	# 20 bytes: date/time
	$date = unpack("a*", fread($fh, 20));
	$date = strptime($date[1], "%d %b %y  %H:%M:%S");
	$M->date = mktime(
		$date['tm_hour'], $date['tm_min'], $date['tm_sec'],
		$date['tm_mon'] + 1, $date['tm_mday'], $date['tm_year'] + 1900
	);
	unset($date);

	# message metadata
	$M->recipient = $M->rawRecipient = fgetsz($fh, 36);
	$M->sender = $M->rawSender = fgetsz($fh, 36);
	$M->subject = $M->rawSubject = fgetsz($fh, 72);
	
	$M->rawText = fgetsz($fh);
	$M->text = "";
	
	$rawtext = explode("\x0D", $M->rawText);
	$kludgeLines = 0; # for AREA line detection
	for ($i = 0; $i < count($rawtext); $i++) {
		$line = $rawtext[$i];
		
		if ($line[0] == "\x01") {
			$kludgeLines++;
			# kludge
			$line = substr($line, 1);
			$pos = strpos($line, ": ");
			if ($pos === false) {
				fwrite(STDERR, "Malformed kludge line: {$line}\n");
				continue; # parse next line
			}
			$kname = substr($line, 0, $pos);
			$kvalue = substr($line, $pos+2);
			unset($pos);
			
			# parse the kludge
			switch ($kname) {
			# TODO: MSGID, REPLY, CHRS
			
			case 'MSGID':
				$M->msgid = $kvalue;
				list ($address, $serialno) = explode(" ", $kvalue);
				$M->origin = new Address($address);
				break;
			
			case 'REPLY':
				$M->replyMsgid = $kvalue;
				break;
			
			case 'TID':
				$M->tosserID = $kvalue;
				break;
				
			case 'PID':
				$M->programID = $kvalue;
				break;
			
			case 'CHRS': # FSP-1013
			case 'CHARSET': # back-compat
				list ($charset, $level) = explode(" ", $kvalue);
				
				# some old implementations don't add a level
				if ($level !== null) $level = intval($level);
				
				$charset = kGetCharset($charset, $level);
				if ($charset !== false) $M->originalCharset = $charset;
				
				unset($charset, $level);
				break;

			default:
				$M->kludges[] = array($kname, $kvalue);
			}
			unset($kname, $kvalue);
		}
		elseif ($kludgeLines == 0 and ($pos = strpos($line, ":")) > 0) {
			# FSC-0043: An AREA: line must be the first non ^a line in the text.
			$M->areaType = strtolower(substr($line, 0, $pos));
			$M->areaName = strtolower(substr($line, ++$pos));
		}
		elseif (substr($line, 0, 3) == "---") {
			$M->tearline = trim(substr($line, 3));
			if (VISIBLE_TEARLINES)
				$M->text .= "{$line}\n";
		}
		elseif (substr($line, 0, 11) == " * Origin: ") {
			$M->originLine = trim(substr($line, 11));
			if (VISIBLE_ORIGIN)
				$M->text .= "{$line}\n";
		}
		elseif (substr($line, 0, 11) == " # Origin: ") {
			$M->trueOriginLine = trim(substr($line, 11));
			if (VISIBLE_ORIGIN)
				$M->text .= "{$line}\n";
		}
		elseif (substr($line, 0, 8) == "SEEN-BY:") {
			$M->seenBy[] = trim(substr($line, 8));
			if (VISIBLE_SEENBY)
				$M->text .= "{$line}\n";
		}
		else {
			# text
			$M->text .= "{$line}\n";
		}
	}
	
	if ($M->origin === null and $M->originLine !== null) {
		$o = $M->originLine;
		$startPos = strpos($o, '(');
		$endPos = strpos($o, ')', $startPos);
		$M->origin = new Address(substr($o, ++$startPos, ++$endPos));
		unset($o, $startPos, $endPos);
	}
	
	# assume cp866 by default
	# TODO: use area's default
	if ($M->originalCharset === null)
		$M->originalCharset = 'cp866';
	
	# if we know the original charset, convert to UTF-8
	if (!empty($M->originalCharset)) {
		$M->text = iconv($M->originalCharset, "utf-8", $M->text);
		$M->recipient = iconv($M->originalCharset, "utf-8", $M->rawRecipient);
		$M->sender = iconv($M->originalCharset, "utf-8", $M->rawSender);
		$M->subject = iconv($M->originalCharset, "utf-8", $M->rawSubject);
	}
	
	$_GLOBALS["messageCount"]++;
	return $M;
}


mb_internal_encoding("utf-8");

if ($argc < 2) {
	fwrite(STDERR, "Must specify PKT file name\n");
	exit(1);
}
# shift off my pathname
else array_shift($argv);

# for each pkt...
while ($fname = array_shift($argv)) {
	if (!is_file($fname)) {
		fwrite(STDERR, "File not found: {$fname}\n");
		continue;
	}
	
	$fh = fopen($fname, "rb");
	if (!is_resource($fh)) {
		fwrite(STDERR, "Failed to open {$fname}\n");
		continue;
	}
	#echo "Reading {$fname}\n";
	
	$packet = readpkt($fh);
	
	foreach ($packet->messages as $M) {
		$out = STDOUT;
		
		fwrite($out, "From - ".strftime(TIMEFORMAT_MBOX, $M->date)."\n");
		
		$M->origin->domain = "fidonet";
		# TODO: make MIME-friendly
		$from = "\"{$M->sender}\" <{$origin}>";
		$to = $M->recipient;
		$subject = $M->subject;
		
		if ($M->originalCharset !== null) {
			# we have UTF-8
			$from = mb_encode_mimeheader($from, "utf-8", "Q", "\n", strlen("From: "));
			$to = mb_encode_mimeheader($to, "utf-8", "Q", "\n", strlen("To: "));
			$subject = mb_encode_mimeheader($subject, "utf-8", "Q", "\n", strlen("Subject: "));
		}
		
		fwrite($out, "From: {$from}\n");
		fwrite($out, "To: {$to}\n");
		fwrite($out, "Subject: {$subject}\n");
		if ($M->originalCharset !== null) {
			fwrite($out, "Content-Type: text/plain; charset=utf-8\n");
		}
		
		fwrite($out, "Date: ".strftime(TIMEFORMAT_RFC2822, $M->date)."\n");
		
		if (!empty($M->tearline))
			fwrite($out, "X-FidoNet-Tearline: {$M->tearline}\n");
		
		if (!empty($M->originLine))
			fwrite($out, "X-FidoNet-Origin: {$M->originLine}\n");
		
		if (!empty($M->trueOriginLine))
			fwrite($out, "X-FidoNet-TrueOrigin: {$M->trueOriginLine}\n");
		
		if (!empty($M->programID))
			fwrite($out, "X-FidoNet-Program: {$M->programID}\n");
		
		if (!empty($M->tosserID))
			fwrite($out, "X-FidoNet-Tosser: {$M->tosserID}\n");
		
		foreach ($M->kludges as $kludge) {
			list ($k, $v) = $kludge;
			fwrite($out, "X-FidoNet-Kludge: {$k}={$v}\n");
		}		
		unset ($kludge, $k, $v);
		
		fwrite($out, "Content-Transfer-Encoding: 8bit\n");
		fwrite($out, "Content-Length: ".strlen($M->text)."\n");
		fwrite($out, "Lines: ".count(explode("\n", $M->text))."\n");
		
		fwrite($out, "\n{$M->text}\n");
	}
}
